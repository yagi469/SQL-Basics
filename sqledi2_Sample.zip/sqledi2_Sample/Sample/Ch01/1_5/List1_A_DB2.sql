--DB2
RENAME TABLE Sohin TO Shohin;