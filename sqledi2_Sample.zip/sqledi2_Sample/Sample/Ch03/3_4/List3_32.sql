SELECT shohin_id AS id, shohin_mei, hanbai_tanka AS ht, shiire_tanka
  FROM Shohin
 ORDER BY ht, id;