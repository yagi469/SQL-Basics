--SQL Server PostgreSQL MySQL
SELECT (100 + 200) * 3 AS keisan;