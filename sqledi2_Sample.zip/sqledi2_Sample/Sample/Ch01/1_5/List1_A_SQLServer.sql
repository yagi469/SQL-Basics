--SQL Server
sp_rename 'Sohin', 'Shohin';