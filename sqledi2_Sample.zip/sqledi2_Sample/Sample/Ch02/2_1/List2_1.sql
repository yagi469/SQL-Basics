SELECT shohin_id, shohin_mei, shiire_tanka
  FROM Shohin;