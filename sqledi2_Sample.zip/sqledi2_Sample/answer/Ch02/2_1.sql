SELECT shohin_mei, torokubi
  FROM Shohin
 WHERE torokubi > '2009-04-28';