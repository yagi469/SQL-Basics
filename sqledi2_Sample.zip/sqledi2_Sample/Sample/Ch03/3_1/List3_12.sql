SELECT SUM(hanbai_tanka), SUM(DISTINCT hanbai_tanka)
  FROM Shohin;