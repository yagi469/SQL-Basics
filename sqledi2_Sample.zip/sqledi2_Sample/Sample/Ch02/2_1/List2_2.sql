SELECT *
  FROM Shohin;