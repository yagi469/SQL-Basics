--Oracle�ADB2
SELECT str1,
       SUBSTR(str1, 3, 2) AS sub_str
  FROM SampleStr;