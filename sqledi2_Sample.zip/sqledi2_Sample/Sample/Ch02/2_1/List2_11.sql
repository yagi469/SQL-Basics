SELECT shohin_mei
  FROM Shohin
 WHERE shohin_bunrui = '�ߕ�';