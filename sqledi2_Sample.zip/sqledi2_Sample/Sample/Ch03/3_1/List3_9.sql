SELECT MAX(torokubi), MIN(torokubi)
  FROM Shohin;