SELECT COALESCE(str2, 'NULL�ł�')
  FROM SampleStr;