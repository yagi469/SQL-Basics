--Oracle�ADB2�APostgreSQL�AMySQL
SELECT str1,
       LENGTH(str1) AS len_str
  FROM SampleStr;