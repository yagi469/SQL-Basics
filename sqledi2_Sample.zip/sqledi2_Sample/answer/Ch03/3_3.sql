SELECT *
  FROM Shohin
 ORDER BY torokubi DESC, hanbai_tanka;