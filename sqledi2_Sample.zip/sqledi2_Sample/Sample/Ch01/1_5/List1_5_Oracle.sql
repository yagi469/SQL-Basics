--Oracle
ALTER TABLE Shohin DROP (shohin_mei_kana);