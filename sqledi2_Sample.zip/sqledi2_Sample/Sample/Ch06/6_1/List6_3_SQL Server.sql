--SQL Server
SELECT n, p,
       n % p AS mod_col
  FROM SampleMath;