SELECT shohin_mei, shohin_bunrui
  FROM Shohin
 WHERE shohin_bunrui = '�ߕ�';