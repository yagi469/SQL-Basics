SELECT DISTINCT shiire_tanka
  FROM Shohin;