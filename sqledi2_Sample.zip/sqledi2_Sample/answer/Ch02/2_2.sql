/*
  �ȉ���
  ���SELECT��
*/
-- �@
SELECT *
      FROM Shohin
     WHERE shiire_tanka = NULL;

-- �A
SELECT *
      FROM Shohin
     WHERE shiire_tanka <> NULL;

-- �B
SELECT *
      FROM Shohin
     WHERE shohin_mei > NULL;