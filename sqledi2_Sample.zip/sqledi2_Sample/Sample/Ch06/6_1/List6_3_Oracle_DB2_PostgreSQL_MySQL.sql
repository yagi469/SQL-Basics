--Oracle�ADB2�APostgreSQL�AMySQL
SELECT n, p,
       MOD(n, p) AS mod_col
  FROM SampleMath;