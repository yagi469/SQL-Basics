--SQL Server�APostgreSQL
SELECT CAST('0001' AS INTEGER) AS int_col;