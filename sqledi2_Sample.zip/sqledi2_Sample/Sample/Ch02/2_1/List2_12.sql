SELECT shohin_mei, shohin_bunrui
 WHERE shohin_bunrui = '�ߕ�'
  FROM Shohin;