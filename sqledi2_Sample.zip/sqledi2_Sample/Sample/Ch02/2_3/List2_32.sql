SELECT shohin_mei, shohin_bunrui
  FROM Shohin
 WHERE hanbai_tanka < 1000;