SELECT shohin_mei, shiire_tanka
  FROM Shohin
 WHERE shiire_tanka =  320
    OR shiire_tanka =  500
    OR shiire_tanka = 5000;