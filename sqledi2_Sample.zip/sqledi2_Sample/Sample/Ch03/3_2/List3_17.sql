SELECT shohin_bunrui AS sb, COUNT(*)
  FROM Shohin
 GROUP BY sb;