UPDATE Shohin
   SET torokubi = NULL
 WHERE shohin_id = '0008';

--�ύX���e�̊m�F
SELECT * FROM Shohin ORDER BY shohin_id;