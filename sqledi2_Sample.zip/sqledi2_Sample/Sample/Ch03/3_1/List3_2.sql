SELECT COUNT(shiire_tanka)
  FROM Shohin;