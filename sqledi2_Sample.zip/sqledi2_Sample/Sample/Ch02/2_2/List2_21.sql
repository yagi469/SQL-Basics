SELECT shohin_mei, shohin_bunrui, torokubi
  FROM Shohin
 WHERE torokubi < '2009-09-27';