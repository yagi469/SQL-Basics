--SQL Server
SELECT str1,
       SUBSTRING(str1, 3, 2) AS sub_str
  FROM SampleStr;