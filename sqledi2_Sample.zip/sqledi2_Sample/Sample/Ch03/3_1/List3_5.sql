SELECT SUM(hanbai_tanka), SUM(shiire_tanka)
  FROM Shohin;