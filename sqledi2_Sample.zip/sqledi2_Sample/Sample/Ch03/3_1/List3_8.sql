SELECT MAX(hanbai_tanka), MIN(shiire_tanka)
  FROM Shohin;