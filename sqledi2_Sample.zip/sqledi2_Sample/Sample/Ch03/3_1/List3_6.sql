SELECT AVG(hanbai_tanka)
  FROM Shohin;