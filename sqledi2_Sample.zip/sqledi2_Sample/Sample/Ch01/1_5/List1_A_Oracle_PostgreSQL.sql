--Oracle PostgreSQL
ALTER TABLE Sohin RENAME TO Shohin;